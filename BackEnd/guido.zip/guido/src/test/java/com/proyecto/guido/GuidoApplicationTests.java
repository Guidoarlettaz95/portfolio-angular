package com.proyecto.guido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
